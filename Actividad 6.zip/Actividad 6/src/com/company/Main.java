package com.company;

public class Main {

    public static void main(String[] args) {
    Grades grades = new Grades();
    grades.calculate_grades();
    grades.show_Results();
    }
}
