package com.company;

public class Grades {
    String name;
    int average=0;

    int [] grades = {70,65,90,81,100};
    public void calculate_grades(){
        int container = 0;
        for (container=0; container<grades.length; container++){
            average+=grades[container]/5;
        }
    }
    public String letters(){
        if (average<=50){
            System.out.println("The student has an F");
        }
        if (average>=51 && average <=60){
            System.out.println("The student has an E");
        }
        if (average>=61 && average <=70){
            System.out.println("The student has a D");
        }
        if (average>=71 && average <=80){
            System.out.println("The student has a C");
        }
        if (average>=81 && average <=90){
            System.out.println("The student has a B");
        }
        if (average>=91 && average <=100){
            System.out.println("The student has an A");
        }
       return "";
    }
    public void show_Results(){
        name="Oved";
        System.out.println("Student Name: "+name);
        System.out.println("The 1st grade: "+grades[0]);
        System.out.println("The 2nd grade: "+grades[1]);
        System.out.println("The 3rd grade: "+grades[2]);
        System.out.println("The 4th grade: "+grades[3]);
        System.out.println("The 5th grade: "+grades[4]);
        System.out.println("The average is: "+average);
        System.out.println(letters());
    }

}



